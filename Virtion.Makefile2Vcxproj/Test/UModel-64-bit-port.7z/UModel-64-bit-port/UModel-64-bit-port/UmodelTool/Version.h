#define GIT_REVISION unknown

#ifndef __MISC_STRINGS_H__
#define __MISC_STRINGS_H__

extern const char* GUmodelHomepage;

extern const char* GBuildString;
extern const char* GCopyrightString;

#endif // __MISC_STRINGS_H__

#!/bin/bash

project="extract"
root="../.."
render=0
source $root/build.sh

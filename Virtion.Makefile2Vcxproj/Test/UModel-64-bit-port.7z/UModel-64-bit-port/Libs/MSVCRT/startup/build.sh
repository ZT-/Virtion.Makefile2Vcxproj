#!/bin/bash

file=src/crtexe2.c

OPT_MAIN_2="-GS- -GR- -O1 -EHs- -D CRTDLL -D _CRTBLD -I ./src" # -I ./src/PlatformSDK
CPP="-nologo -c -D WIN32 -D _WINDOWS -MD $OPT_MAIN_2 $file"

vc32tools --compile $CPP
vc32tools --64 --compile $CPP -Fo"crtexe2_64.obj"

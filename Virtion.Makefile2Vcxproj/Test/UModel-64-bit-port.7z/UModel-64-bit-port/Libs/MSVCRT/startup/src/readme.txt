This directory contains files from VC9.0 (2008) CRT source.
crtexe2.c is a modified version of crtexe.c.
